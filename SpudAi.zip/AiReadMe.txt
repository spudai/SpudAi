AiReadMe
created: 03-12-2020
last update: 14-02-2021
current version: AiV021d.exe

This file is for information pertinant to the Ai that hasn't been uploaded to another place or information that has no other place to go. 

Contents
	Keywords, new Keywords and updated information for existing Keywords
	Brain cells, new cell usage and updates for existing cells
	Tags, new tags and updates for existing Tags
	Mouse

********************************************************************************
KEYWORDS

NNActivateCell if there is nothing or text in field 11 then the current cell is activated. This keyword is another way of activating cells when an input is processed. If your activating a cell from within a function like ST of SC normally you would set the Operation field to 3 but in some situations this might not work as you want, if this happens use NNActivateCell

functionrq err what does this do?

CheckBrainFields checks brain fields for errors. If mode = 1 then a special function is used to remove the number 803 from node to cell field 5 and 1 from node to cell fields 6. This will evolve into a function to clean all node to cell fields easly if they become corupted. If the output says 0 then the function has been bypassed. If 1 then function activated but nothing found. Higher than 1 number of times error found.

InputFilter input filter is also a function used if ticked in settings.
There are three routines that filter the input before main processing starts 
InputFilter() extracts words from the input using string5 
InputFiltre() removes unwanted charictures like commers brackest etc... this function could be optimized
SpecialSCFunctions() incoporates the InputFunction. InputFunction performs a task on the two words with an operator seperating them. E.g if you want to point the word fish to the word swim then the input would look like this fish>swim 
if = is found between two words then the two words entries are swopped. In effect the cell numbers of the words are swapped. E.g fish=swim
if > is found between two words then the first word is set to point to the second word by changing the next avaliable Node to Cell field to the cell number of the second word. If any of the words are missing from the BD then nothing happens.  E.g fish>swim
if < is found between two words then the cell number of the second word is no longer pointed at by removing from the Node to Cell fields any refrances found. If any of the words are missing from the BD then nothing happens. E.g fish<swim
if ^ is found between two words then the first word is changed to the second word. This is mostly used if you have a badly spelt word in the BD that you want to change from an input. If the second word is already in the BD then the change wont happen as this would mean there would be two words the same in the BD. This is not a problem but can cause unexpected outputs. E.g fish^swim
Cell 928 is used by the function. NoteToMe! system cells 928 in help needs also updating with the following:
field 7 = first word
field 8 = second word
field 10 = function
field 11 = second word if not found in the BD, if found then set to empty
node to cell field 1 = first word cell number
node to cell field 2 = second word cell number
if order = 3 then cell 928 is activated 
if mode = 0 then the ai exits the ProcessInput routine immediatly after the InputFunction has finnished. If anything else the input is processed normally
The input variable WordsIn is set to the two words with a space between the two 
The bad word variable is reset to stop interference to other routines.
The InputFunction is over-ridden if the ai finds the word in the BD. The ai needs to see it as a bad word. 
Changing what a word points to has an effect on the neural network and learning functions.
The SpecialSCFunctions() process is also used by WSB.
Connected words are produced by the CON function and can also be seen in field 10 cell 911. If you enter a single word you will see the connected words for that word.  If a word here is out of place then it can be removed using the < function. If you want to add a word use the > If you make a change and you dont see the word appear then this might be because you have a double entry for the word, so only one of the entries is being changed. To fix this delete one of the entries in the BD. 

**** has the below been implamented?
An input filter would be usefull so yu could use a spacific word in the input for say searches surgested functions are
keyword		= inputfilter
mode		= filter used
operation 	= word number in input
order		= number of words to use
mode = 0 set ToPrint to word or words 
mode = 1 set SwopVar to word or words
mode = 2 set ToPrint to word or words then activate cell
mode = 3 set SwopVar to word or words then activate cell
****

CheckBrainFields checks the brain fields for errors with details sent to the debug print function. CheckBrainFields is run at startup with a minimal amount of information sent to the debug output. CBFInt02 errors are when a field in the BD has incorrect or invalid data. CBFInt04 count is the number of times the cell number has been found in the Node to Cell fields, this is a possible cause of DID errors. If you run  CheckBrainFields as a keyword then if DebugOn is active then the cell numbers are also displayed.

PlayPlaylist update cell 907 info so playlist is serchable

AutoLearn if <all> is found in the Tags field then all of the LM function is used. This means that the looked up word is search for in the BD and if not found added. Also the word type filter is invoked so when the word is added the Type field is also changed if noun, verb, adjective, adverb or conjunction are found in the output file.

FunctionRQ runs the ProcessInput function using the RQ values in field 10. The original RQ values are stored in field 11 and used to reset the values once the keyword has finnished. The ToPrint variable is processed instead of the input and set to the result. To bypass a function set the RQ value to 0.

Sum 
mode = 9  AND logic operator
mode = 10 OR logic gate
mode = 11 convert a base 10 number to a base 2 number
mode = 12 convert a base 2 9 digit number to a base 10 number

FileSearchTwo new name for ScanDownload this is old code for seaching and has been supeceeded by other functions. Its been left in at the moment as i dont quite understand what it does.
Its slow probably cos its coded bad coz its ery old code redescovered, its due a code clean up or remove.

FileSearch add the input code of cell 1600 is set to the number of times found, also field 7 is set to the number of times found

ImageStep this sets the step value like cell 947. The Type field sets the value which should be between 1 and 11. This changes the step value variable. If the DX window is reopend then the step value will be reset to the value in the Type field of cell 947. 

DTLearn now works with ST generated outputs. If field 8 is empty then the contents of field 11 are put in it and file 11 is changed to the words after the DT learning trigger words. This works in the same way as SC codes.

iptxfromfile and iprxfromfile removed to make more room in main program, these processes can be done in other ways i think code left in source for now in case a reversal is needed

ExportBrainToCSV the file created is called TFToCSV.csv

DTLearn
if the nn rq setting number 22 is at 0 then you might get a file read error if using dt learning
ST codes are now updated using DTLearn this works in the same way as SC codes. If the previous output was produced by the ST function then DTLearn is triggered in the next input, the words after the trigger replace the contents of field 11 if field 8 is empty. The existing contents of field 11 are put into field 8 after the change

ImageChangeSend 
now in main help add extras here
cell 947 is the image functions step value

NNWorkMatrix full path

UpdateNIO updates the number in out variables to the BD cells 1000 to 1175

ImageAnalog 
er what is Fq: on scroll..? its the frequency of blue number of times blue found in a line

ImageShow draws the image variable into the DX window.

FileIndexSearch err where are the results?
posabley searchresults.html in readout folder set by cell 819

UDPRestart

ToDo change
sendtoip to UDPSendToIP

ImageLoad 

MapCreate

MapShow
The image cls.jpg is loaded before the map is draw, the cls.jpg image is in the image folder
If Order field = 1 then the DX window is used

MapPlace 
Field 7 if empty then automatic values are set by information from cell 1624. A number in field 7 between 1 and 60 like a clock is
the direction the robot is facing. The position is set by the Mode and Operation fields.
This works out what the robot can see from information from the map. 
Map data is held in the LocationFile.dat  
Mode = left position 1 to 320
Operation = top position 1 to 240

Order = which window to use
Order = 0 use image window
Order = 1 use DX window

Alarm field 7 = time is field 8 the note?

updatesettings now includes updating the alarm variable
functions:
SettingsDataLoad()
AlarmSetUp()

CleanNode this needs looking at and changing it resets all in cell fields also has a messagebox

********************************************************************************
BRAIN CELLS

1745 next cell

1744 Activated if the CON process finds no output. Cell 1744 is activated if for some reason there is no output, this can be used to create an answer in these circumstances. Because the cell is activated during the SayPrint function some output places that would normally show the output might not.

911 field 10 contains the connected words found by the CON process

1042 field 7 is set to 0 or 1. If 1 then a space has been found in the output indicating there is more than word in the output. 

1743 activated when image data has been received

1119 holds the Fq value from the ImageAnalog routine. The fq value is the number of times of what...? find out

2000 all fields are cleared by the CheckFix routine if reset is found

924, LOOK AT CODE THIS NEEDS UPDATING: WordsNotToUse()
Cell type exclude. Excludes the cell types from various outputs so sentence codes, special words and other word types as defined in the cells type filed can be excluded from certian processes like 6p and NNE. Field 11 holds the word types to exclude
defalt excluded word types: 
field 11 =	32 60 72 96 118 131 0 132 120 40 102 103 450 

********************************************************************************
TAGS

<speak:n> Where n is a number. This tag has changed the mode value is now set from the number after the colon eg. <speak:0>

<playmidi> NN code is in reverse needs swopping round

<lookup> what does this do

<grammar:n> Where n is a number. At the moment this tag uses 2 functions. 
Function: 
1 uses the OutputFilterTwo process. 
2 uses OutputFilterFour. 
eg <grammer:2> will use the SC found in the BD to rearraing the words in the ToPrint variable.

<stow> mode = left position, Operation = top position

<once> use the keyword ClearTagOnce to reset the Once variable

<rq=> has been changed to <rq:> colon denotes a base 10 number, equal is used for a base 2 number
eg. <rq:6>

<LookUp:> set the 

<iftp=sv-ac:n> Where n is a cell number. If the output variable ToPrint is the same as the SwopVar variable then activate the cell.
eg.  <iftp=sv-ac:100>

<toprint-f12> puts the contents of ToPrint variable into the Detail field also know as Field 12

<toprint-f01> puts the contents of ToPrint variable into the Mode field ToPrint should be a number if text then the number will be 0
<toprint-f02> puts the contents of ToPrint variable into the Operation field ToPrint should be a number if text then the number will be 0
<toprint-f03> puts the contents of ToPrint variable into the Order field ToPrint should be a number if text then the number will be 0
<toprint-f04> puts the contents of ToPrint variable into the Type field ToPrint should be a number if text then the number will be 0
<toprint-i> converts the number in the ToPrint variable into a binary number and then sets the input code

<uwbutton>
detail field is the text of the tooltip which appears when you hover the mouse over the button

<filter:3> this extracts the new words from the ToPrint variable. It compairs the previous input to the filter with the present input and changes the ToPrint variable to the new words. 

<filter:4> sets the ToPrint variable to the bad word if there is a bad word in the input. ToPrint is set to the value of UDPBadWord which is set by the SC function.

<nodewords-cell:> uses the node words from the specified cell number, if set to 0 then the cell found by <lookup-cell> is used
the output code from the cell holding the tag is used instead of the word found output code

<LookUp:n> where n is the number of cell to set the variables LookUpNumber which is used by <ToPrint-fn> where fn is the function

<lookup-cell> this looks in the BD for the word in the ToPrint variable if found the variable LookUpNumber is set to the cell number of the word found.
if the contents of ToPrint is a number then this number is used to set LookUpNumber

The LookUp variable LookUpNumber is now reset when a cell activation occurs, it wasn't like this before this stops the LookUp cell number carying through from other cell activations which in some cases might be useful so keep an eye on it.

<f9-cell:>

<all> needs looking at why disabled?

nodewords needs looking at

out-wotf

<uwface> add more detail help
field		description
mode		left position
operation	top position
field 7		rgb code for the white part of the eyes
field 8		rgb code for the colour of the face
field 10	rgb code for the outline and mouth elements		
field 11	NN code used to control the eyes

********************************************************************************
AI SERVER AISERVER

SendReplyBallence variable as seen in the debug output. This shows the ballence between messages that are sent and received from the ai. When a messeage is sent to Ai the value is decreased, when a message is received from the ai the value is increased. This is used to ditect communication errors between the server and the Ai. The Error function activates when the SendReplyBallence value is below -2
If an error is detected then if the Error: value in the INI file is set then the value after Error: is assumed to be a program to execute eg.
Error: C:\AiServer\Error\AiV020b.exe
I start an instance of my Ai program to perform an action if the server detects an error. 
If AiCell is in the input then the SendReplyBallence is set to 0.
If AiMode is 0 or 1 then the SendReplyBallence variable is not altered.

I've noticed on Opera browser that if I send text within 7 seconds of receipt of output then the first send doesn't get through the second send does. If i wait for 7 seconds then it seems to work every time.

note when sending back the server now looks for -o which is added to the windows message from the ai and means: to output. The whole code is o-o meaning output to output

If you want to send a text input to the ai from the web address only you can use the keyword postvar= followed by the words seperated by a plus + and an & symbol at the end, the end symbol is important without it the text sent to the ai will be: format_error 
In the examples lovo is the name of the computer the server is running on, it's my local machine
http://lovo/postvar=fish&
will send the word "fish" to the ai
http://lovo/postvar=what+is+a+fish&
will send the words "what is a fish" to the ai

********************************************************************************
MOUSE

Mouse is a security program.
An instruction file is downloaded and read everytime the timer is up.
Any instructions found are acted upon by the program.
When the program starts it is hidden to see the output it needs to find the instruction show: in the downloaded instruction file mouse.txt
When the program starts the file mouse.dat is read and the first line is the web address of the instruction file which is then downloaded after 30 seconds. 
If mouse.dat is empty then the download process is bypassed. mouse.dat is only read once at startup any changes requires a restart of the program.
If download is disabled then the mouse.txt file is read but not updated by a new downloaded file. Changes made to the local file will be acted upon.
If there is no mouse.dat file then the default web address is: http://spudblob.ddns.net/mouse.txt
Pass is the number of times the program has carried out the function.
The button GO activates the function, the timer keeps going.
Sometimes the file is held in the cach and doesnt update imediatly if the file on the server has changed. If you clear Internet Explorers history then a new file will be downloaded.
Only one instance of an instruction is acted upon when the instruction file is read. The last instruction instance found is used.

Instructions:

code:
sets the MouseCode variable with the text, which is sent when requested by the send: instruction.
code: Frog42
send:
Send some information to the server. Sends using posvar= the computer name and the code set by the instruction code: If code: isn't set then only the computer name is sent. The format is used to work with the AiServer program which passes the text after postvar= to an Ai.
URL sent to server: http://MySite/postvar=code:MyComputerNamefrog42
where Frog42 has been set by the instruction code:
show:
Show the Mouse window.
hide:
Hide the mouse window.
settimer:
Set the timer, this is the delay gap between downloads and read file. The value is in seconds. This must be 6 or higher anything lower will case it to defaul to 20 seconds.
settimer: 60
download:
Downloads the file to the mouse folder.
download: http://MySite/MyFile.txt
run:
Runs the file. If the file is already running then it wont run untill it stops. 
If running an exe file then the exe is removed before looking to see what programs are running.
The file ListPrograms.txt is created. If the name used to run the program is different that its window name then the program wont be recognised as running.
Change the name of the program to run to that of the name listed in ListPrograms.txt
run: MyFile.txt
spud:
shows the line in the text output.
spud: hello world

Scroll output codes:
GO  program start
RF  read file
INS instruction
IPR is program running
DLF download file
NE  name extractor 

